import pandas as pd
import plotly.graph_objects as go
import plotly.utils
from flask import Flask, render_template, jsonify, request
import json
import os
import sys

# Add parent directory to path to import main.py
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__, template_folder='templates')

# Global variable to cache dashboard data
cached_dashboard_data = None

def create_performance_plots_by_asset_class(dashboard_data):
    """Creates separate interactive performance plots for each asset class."""
    asset_class_plots = {}
    
    # Black and white color palette for different algorithms
    algorithm_colors = {
        'AA': '#000000',
        'SEAA': '#1f77b4',  # Blue color for SEAA
        'FTL': '#666666',
        'Hedge': '#999999',
        'Foundation': '#cccccc'
    }
    
    # Group data by asset class
    data_by_asset_class = {}
    for series_key, series_data in dashboard_data['performance_series'].items():
        asset_class = series_data['asset_class']
        if asset_class not in data_by_asset_class:
            data_by_asset_class[asset_class] = []
        data_by_asset_class[asset_class].append(series_data)
    
    # Create a plot for each asset class
    for asset_class in sorted(data_by_asset_class.keys()):
        fig = go.Figure()
        series_list = data_by_asset_class[asset_class]
        
        for series_data in series_list:
            algorithm = series_data['algorithm']
            color = algorithm_colors.get(algorithm, '#000000')
            
            fig.add_trace(go.Scatter(
                x=series_data['dates'],
                y=series_data['values'],
                name=algorithm,
                mode='lines',
                line=dict(width=3, color=color),
                hovertemplate=f'<b>{algorithm}</b><br>Date: %{{x}}<br>Value: %{{y:.4f}}<extra></extra>'
            ))
        
        fig.update_layout(
            title={
                'text': f'{asset_class} Asset Class - Portfolio Performance',
                'x': 0.5,
                'xanchor': 'center',
                'font': {'size': 22, 'color': '#000000'}
            },
            xaxis_title='Date',
            yaxis_title='Cumulative Wealth',
            template='plotly_white',
            height=550,
            hovermode='x unified',
            font=dict(size=12, color='#000000'),
            margin=dict(l=60, r=60, t=100, b=60),
            plot_bgcolor='#ffffff',
            legend=dict(
                orientation="v",
                yanchor="top",
                y=0.99,
                xanchor="left",
                x=0.01,
                bgcolor="rgba(255, 255, 255, 1)",
                bordercolor="#000000",
                borderwidth=1,
                font=dict(size=11, color='#000000')
            ),
            xaxis=dict(
                showgrid=True,
                gridwidth=1,
                gridcolor='#cccccc'
            ),
            yaxis=dict(
                showgrid=True,
                gridwidth=1,
                gridcolor='#cccccc'
            )
        )
        
        asset_class_plots[asset_class] = fig
    
    return asset_class_plots


def create_performance_plot(dashboard_data):
    """Creates an interactive performance plot using plotly."""
    fig = go.Figure()
    
    # Distinct color palette for different asset classes
    asset_class_colors = {
        'FX': {'AA': '#1f77b4', 'SEAA': '#0055cc', 'FTL': '#004499', 'Hedge': '#ff6b6b', 'Foundation': '#003366'},
        'RATES': {'AA': '#ff7f0e', 'SEAA': '#ff6600', 'FTL': '#ff5500', 'Hedge': '#ff4400', 'Foundation': '#ff3300'},
        'EQUITY': {'AA': '#2ca02c', 'SEAA': '#22aa22', 'FTL': '#1a8800', 'Hedge': '#118800', 'Foundation': '#086600'}
    }
    
    for series_key, series_data in dashboard_data['performance_series'].items():
        asset_class = series_data['asset_class']
        algorithm = series_data['algorithm']
        
        # Get color based on asset class and algorithm
        if asset_class in asset_class_colors and algorithm in asset_class_colors[asset_class]:
            color = asset_class_colors[asset_class][algorithm]
        else:
            color = '#1f77b4'
        
        fig.add_trace(go.Scatter(
            x=series_data['dates'],
            y=series_data['values'],
            name=series_data['name'],
            mode='lines',
            line=dict(width=2.5, color=color),
            hovertemplate='<b>%{fullData.name}</b><br>Date: %{x}<br>Value: %{y:.4f}<extra></extra>'
        ))
    
    fig.update_layout(
        title={
            'text': 'Portfolio Performance Over Time',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 20}
        },
        xaxis_title='Date',
        yaxis_title='Cumulative Wealth',
        template='plotly_white',
        height=600,
        hovermode='x unified',
        font=dict(size=12),
        margin=dict(l=50, r=50, t=80, b=50),
        plot_bgcolor='rgba(240, 240, 240, 0.5)',
        legend=dict(
            orientation="v",
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(255, 255, 255, 0.8)"
        )
    )
    
    return fig

def create_metrics_table(dashboard_data):
    """Creates a formatted table with performance metrics - black and white only."""
    
    if not dashboard_data['metrics']:
        # Return empty table if no metrics
        return go.Figure(data=[go.Table(
            header=dict(values=['No Data Available'],
                       fill_color='#ffffff',
                       font=dict(color='#000000')),
            cells=dict(values=[['Run main.py to generate metrics']],
                      fill_color='#ffffff',
                      font=dict(color='#000000'))
        )])
    
    metrics_df = pd.DataFrame(dashboard_data['metrics'])
    
    # Prepare table data
    header_values = list(metrics_df.columns)
    cell_values = [metrics_df[col].tolist() for col in metrics_df.columns]
    
    # Simple alternating white and light gray rows
    cell_fill_colors = []
    for col_idx, col in enumerate(metrics_df.columns):
        col_colors = []
        for idx, row in metrics_df.iterrows():
            if idx % 2 == 0:
                col_colors.append('#ffffff')
            else:
                col_colors.append('#f5f5f5')
        cell_fill_colors.append(col_colors)
    
    fig = go.Figure(data=[go.Table(
        header=dict(
            values=header_values,
            fill_color='#000000',
            align='center',
            font=dict(color='white', size=12, family='Arial'),
            height=30
        ),
        cells=dict(
            values=cell_values,
            fill_color=cell_fill_colors,
            align='center',
            font=dict(size=11, color='#000000'),
            height=35,
            line=dict(color='#cccccc', width=1)
        )
    )])
    
    fig.update_layout(
        title={
            'text': 'Performance Metrics Summary',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 18, 'color': '#000000'}
        },
        height=400 + len(dashboard_data['metrics']) * 35,
        margin=dict(l=10, r=10, t=80, b=10),
        paper_bgcolor='white',
        plot_bgcolor='white'
    )
    
    return fig

@app.route('/')
def dashboard():
    """Main dashboard route."""
    global cached_dashboard_data
    
    if cached_dashboard_data is None:
        # Return a message to run main.py first
        empty_data = {
            'performance_series': {},
            'metrics': [],
            'asset_classes': []
        }
        asset_class_plots = {'FX': create_performance_plot(empty_data), 
                            'RATES': create_performance_plot(empty_data),
                            'EQUITY': create_performance_plot(empty_data)}
        metrics_fig = create_metrics_table(empty_data)
    else:
        asset_class_plots = create_performance_plots_by_asset_class(cached_dashboard_data)
        metrics_fig = create_metrics_table(cached_dashboard_data)
    
    # Convert plots to JSON for rendering
    plots_json = {}
    for asset_class, fig in asset_class_plots.items():
        plots_json[asset_class] = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    metrics_json = json.dumps(metrics_fig, cls=plotly.utils.PlotlyJSONEncoder)
    
    return render_template('dashboard.html',
                         fx_plot=plots_json.get('FX', '{}'),
                         rates_plot=plots_json.get('RATES', '{}'),
                         equity_plot=plots_json.get('EQUITY', '{}'),
                         metrics_table=metrics_json)

@app.route('/api/data')
def get_data():
    """API endpoint to get dashboard data as JSON."""
    global cached_dashboard_data
    
    if cached_dashboard_data is None:
        return jsonify({'error': 'No data available. Run main.py first.'}), 404
    
    return jsonify(cached_dashboard_data)

@app.route('/api/update-data', methods=['POST'])
def update_data():
    """Update dashboard data from external caller."""
    global cached_dashboard_data
    data = request.get_json()
    cached_dashboard_data = data
    return jsonify({'status': 'success'})

def set_dashboard_data(dashboard_data):
    """Function to set dashboard data from main.py."""
    global cached_dashboard_data
    cached_dashboard_data = dashboard_data

if __name__ == '__main__':
    print("Starting Portfolio Allocation Dashboard...")
    print("Open your browser and navigate to: http://localhost:5000")
    print("Note: Run main.py to generate and display performance data")
    app.run(debug=True, port=5000, use_reloader=False)
#!/usr/bin/env python3
"""
Portfolio Allocation Dashboard Launcher
Runs the algorithm execution and automatically launches the dashboard
"""

import subprocess
import sys
import webbrowser
import time

def main():
    print("="*70)
    print(" PORTFOLIO ALLOCATION DASHBOARD")
    print("="*70)
    print("\n Starting algorithm execution...")
    print("   This may take a few minutes depending on data size.\n")
    
    try:
        # Run main.py
        result = subprocess.run([sys.executable, 'main.py'], check=False)
        
        if result.returncode != 0:
            print("\n Algorithm execution failed!")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n  Execution interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n Error running main.py: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

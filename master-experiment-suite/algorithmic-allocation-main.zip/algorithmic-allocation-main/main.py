import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys

# Import from your organized project files
import portfolio_engine
import data_loader
# --- MODIFIED: Corrected the imports to match the available algorithms ---
from algorithms import (
    AA_Algorithm, 
    SEAA_Algorithm, 
    FollowTheLeader, 
    HedgeAlgorithm, 
    FoundationModel_Placeholder
)

def smooth_holding_period(signal_df, hp_days_s):
    """Applies a rolling mean based on holding period to smooth signals."""
    if isinstance(signal_df, pd.Series):
        signal_df = pd.DataFrame(signal_df)
    smooth_signal_df = pd.DataFrame()
    for name in signal_df.columns:
        if name in hp_days_s.index:
            window_size = int(hp_days_s.get(name, 1))
            smooth_signal_s = signal_df[name].rolling(window_size, min_periods=1).mean()
            smooth_signal_df[name] = smooth_signal_s
    return smooth_signal_df.reindex(signal_df.index)

def run_algorithms():
    """
    Run all algorithms and return the results for dashboard display
    """
    # Your existing algorithm execution code here
    # This function should return detailed_results and all_results
    
    return detailed_results, all_results

def prepare_dashboard_data(detailed_results, all_results):
    """
    Prepares data for dashboard visualization instead of creating CSV files.
    Returns dashboard-ready data structures.
    """
    print("\n--- PREPARING DASHBOARD DATA ---")
    
    dashboard_data = {
        'performance_series': {},  # For line charts
        'metrics': [],  # For metrics table
        'asset_classes': []
    }
    
    for asset_class, algos_data in detailed_results.items():
        dashboard_data['asset_classes'].append(asset_class.upper())
        
        for algo_name, data in algos_data.items():
            try:
                # Get algorithm performance
                algo_perf = next((res for res in all_results 
                                if res['Asset Class'] == asset_class.upper() 
                                and res['Algorithm'] == data['algorithm'].name), None)
                
                # Extract portfolio returns
                portfolio_results = data['portfolio_results']
                if portfolio_results and 't_port_ret' in portfolio_results:
                    t_port_ret = portfolio_results['t_port_ret']
                    if isinstance(t_port_ret, pd.DataFrame) and not t_port_ret.empty:
                        # Calculate cumulative returns for plotting
                        port_ret_s = t_port_ret.sum(axis=1) if t_port_ret.shape[1] > 1 else t_port_ret.iloc[:, 0]
                        cumulative_returns = (1 + port_ret_s).cumprod()
                        
                        # Store time series data
                        key = f"{asset_class}_{algo_name}"
                        dashboard_data['performance_series'][key] = {
                            'dates': cumulative_returns.index.astype(str).tolist(),
                            'values': cumulative_returns.values.tolist(),
                            'asset_class': asset_class.upper(),
                            'algorithm': algo_name,
                            'name': f"{asset_class.upper()} - {algo_name}"
                        }
                        
                        # Calculate additional metrics for the table
                        if algo_perf:
                            returns = algo_perf['Returns']
                            
                            # Calculate max drawdown
                            cum_ret = (1 + returns).cumprod()
                            rolling_max = cum_ret.expanding().max()
                            max_drawdown = ((cum_ret - rolling_max) / rolling_max).min()
                            
                            # Calculate Sortino ratio
                            downside_returns = returns[returns < 0]
                            downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
                            sortino_ratio = algo_perf['Mean Return'] / downside_std if downside_std != 0 else 0
                            
                            # Calculate Calmar ratio
                            calmar_ratio = abs(algo_perf['Mean Return'] / max_drawdown) if max_drawdown != 0 else 0
                            
                            dashboard_data['metrics'].append({
                                'Asset Class': asset_class.upper(),
                                'Algorithm': algo_name,
                                'Sharpe Ratio': round(algo_perf['Sharpe Ratio'], 4),
                                'Annualized Return': f"{algo_perf['Mean Return']:.2%}",
                                'Volatility': f"{algo_perf['Std Dev']:.2%}",
                                'Max Drawdown': f"{max_drawdown:.2%}",
                                'Sortino Ratio': round(sortino_ratio, 4),
                                'Calmar Ratio': round(calmar_ratio, 4),
                                'Win Rate': f"{(returns > 0).mean():.2%}"
                            })
                            
                            print(f"   Dashboard data prepared for {asset_class.upper()} - {algo_name}")
                
            except Exception as e:
                print(f"    Error preparing dashboard data for {asset_class}-{algo_name}: {e}")
    
    print(f"\n Dashboard data prepared with {len(dashboard_data['performance_series'])} performance series")
    return dashboard_data


def create_detailed_csv_reports(detailed_results, all_results):
    """
    Creates comprehensive CSV files for each asset class showing:
    - Input data (returns, signals, transaction costs)
    - Algorithm outputs (weights, portfolio returns)
    - Decision reasoning and performance metrics
    """
    print("\n--- GENERATING DETAILED CSV REPORTS ---")
    
    import os
    output_dir = "csv_reports"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    for asset_class, algos_data in detailed_results.items():
        print(f"\nCreating CSV reports for {asset_class.upper()} asset class...")
        
        # Get performance summary for this asset class
        asset_performance = [res for res in all_results if res['Asset Class'] == asset_class.upper()]
        
        for algo_name, data in algos_data.items():
            try:
                # Get algorithm performance
                algo_perf = next((res for res in asset_performance if res['Algorithm'] == data['algorithm'].name), None)
                
                # Prepare comprehensive dataset
                input_returns = data['input_returns']
                input_signals = data['input_signals']
                portfolio_results = data['portfolio_results']
                
                # Create main dataframe starting with dates
                if hasattr(input_returns.index, 'date'):
                    dates = input_returns.index
                else:
                    dates = input_returns.index
                    
                report_df = pd.DataFrame(index=dates)
                
                # Prepare all data columns at once to avoid fragmentation
                all_data_dict = {}
                
                # Add input data columns
                if isinstance(input_returns, pd.DataFrame):
                    for col in input_returns.columns:
                        if isinstance(col, tuple):
                            col_name = f"Return_{col[0]}_{col[1]}" if len(col) > 1 else f"Return_{col[0]}"
                        else:
                            col_name = f"Return_{col}"
                        all_data_dict[col_name] = input_returns[col]
                
                # Add signal data
                if isinstance(input_signals, pd.DataFrame):
                    for col in input_signals.columns:
                        if isinstance(col, tuple):
                            col_name = f"Signal_{col[0]}_{col[1]}" if len(col) > 1 else f"Signal_{col[0]}"
                        else:
                            col_name = f"Signal_{col}"
                        all_data_dict[col_name] = input_signals[col]
                
                # Add portfolio outputs
                if portfolio_results:
                    # Portfolio returns
                    if 't_port_ret' in portfolio_results and portfolio_results['t_port_ret'] is not None:
                        port_ret = portfolio_results['t_port_ret']
                        if isinstance(port_ret, pd.DataFrame):
                            if port_ret.shape[1] == 1:
                                all_data_dict['Portfolio_Return'] = port_ret.iloc[:, 0]
                                returns_col = 'Portfolio_Return'
                            else:
                                all_data_dict['Portfolio_Return_Total'] = port_ret.sum(axis=1)
                                returns_col = 'Portfolio_Return_Total'
                                # Add individual portfolio returns (limit to first 5 to avoid too many columns)
                                for i, col in enumerate(port_ret.columns[:5]):
                                    col_name = f"Portfolio_Return_{col}" if not isinstance(col, tuple) else f"Portfolio_Return_{col[0]}"
                                    all_data_dict[col_name] = port_ret[col]
                    
                    # Portfolio weights (limit to first 5 to avoid too many columns)
                    if 't_port_wght' in portfolio_results and portfolio_results['t_port_wght'] is not None:
                        weights = portfolio_results['t_port_wght']
                        if isinstance(weights, pd.DataFrame):
                            for i, col in enumerate(weights.columns[:5]):
                                col_name = f"Weight_{col}" if not isinstance(col, tuple) else f"Weight_{col[0]}"
                                all_data_dict[col_name] = weights[col]
                
                # Add decision-making columns
                all_data_dict['Algorithm_Name'] = data['algorithm'].name
                all_data_dict['Asset_Class'] = asset_class.upper()
                
                # Add performance metrics (repeated for each row for easy filtering)
                if algo_perf:
                    all_data_dict['Annualized_Return'] = algo_perf['Mean Return']
                    all_data_dict['Annualized_Volatility'] = algo_perf['Std Dev']
                    all_data_dict['Sharpe_Ratio'] = algo_perf['Sharpe Ratio']
                
                # Add transaction cost impact
                try:
                    if asset_class in data['tcost'].index:
                        all_data_dict['Transaction_Cost'] = data['tcost'][asset_class]
                    else:
                        # If tcost is a series with multiple assets
                        for idx in data['tcost'].index:
                            if asset_class.lower() in str(idx).lower():
                                all_data_dict['Transaction_Cost'] = data['tcost'][idx]
                                break
                        else:
                            all_data_dict['Transaction_Cost'] = 0.001  # Default transaction cost
                except:
                    all_data_dict['Transaction_Cost'] = 0.001  # Default transaction cost
                
                # Create the final DataFrame from dictionary (much more efficient)
                report_df = pd.DataFrame(all_data_dict, index=dates)
                
                # Add calculated columns
                if 'Portfolio_Return' in report_df.columns:
                    returns_col = 'Portfolio_Return'
                elif 'Portfolio_Return_Total' in report_df.columns:
                    returns_col = 'Portfolio_Return_Total'
                else:
                    returns_col = None
                    
                if returns_col and not report_df[returns_col].isna().all():
                    # Add cumulative performance
                    report_df['Cumulative_Wealth'] = (1 + report_df[returns_col]).cumprod()
                    
                    # Rolling Sharpe (20-day)
                    rolling_returns = report_df[returns_col].rolling(window=20, min_periods=1)
                    report_df['Rolling_20d_Return'] = rolling_returns.mean() * 252
                    report_df['Rolling_20d_Volatility'] = rolling_returns.std() * np.sqrt(252)
                    with np.errstate(divide='ignore', invalid='ignore'):
                        report_df['Rolling_20d_Sharpe'] = report_df['Rolling_20d_Return'] / report_df['Rolling_20d_Volatility']
                    
                    # Drawdown calculation
                    cumulative_returns = (1 + report_df[returns_col]).cumprod()
                    rolling_max = cumulative_returns.expanding().max()
                    report_df['Drawdown'] = (cumulative_returns - rolling_max) / rolling_max
                
                # Note: Decision reasoning removed for cleaner output
                
                # Save main detailed report
                filename = f"{output_dir}/{asset_class}_{algo_name}_detailed_report.csv"
                report_df.to_csv(filename)
                print(f"   {filename} ({len(report_df)} rows, {len(report_df.columns)} columns)")
                
                # Create separate dataframe for input data used by algorithm - using efficient concat
                data_dict = {}
                
                # Add returns data
                if isinstance(input_returns, pd.DataFrame):
                    for col in input_returns.columns:
                        if isinstance(col, tuple):
                            col_name = f"Return_{col[0]}_{col[1]}" if len(col) > 1 else f"Return_{col[0]}"
                        else:
                            col_name = f"Return_{col}"
                        data_dict[col_name] = input_returns[col]
                
                # Add signals data
                if isinstance(input_signals, pd.DataFrame):
                    for col in input_signals.columns:
                        if isinstance(col, tuple):
                            col_name = f"Signal_{col[0]}_{col[1]}" if len(col) > 1 else f"Signal_{col[0]}"
                        else:
                            col_name = f"Signal_{col}"
                        data_dict[col_name] = input_signals[col]
                
                # Get transaction cost
                try:
                    if asset_class in data['tcost'].index:
                        tcost_value = data['tcost'][asset_class]
                    else:
                        for idx in data['tcost'].index:
                            if asset_class.lower() in str(idx).lower():
                                tcost_value = data['tcost'][idx]
                                break
                        else:
                            tcost_value = 0.001
                except:
                    tcost_value = 0.001
                
                # Get holding period
                try:
                    if asset_class in data['holding_periods'].index:
                        hp_value = data['holding_periods'][asset_class]
                    else:
                        for idx in data['holding_periods'].index:
                            if asset_class.lower() in str(idx).lower():
                                hp_value = data['holding_periods'][idx]
                                break
                        else:
                            hp_value = 1
                except:
                    hp_value = 1
                
                # Create dataframe efficiently using pd.concat
                data_dict['Algorithm'] = data['algorithm'].name
                data_dict['Asset_Class'] = asset_class.upper()
                data_dict['Transaction_Cost'] = tcost_value
                data_dict['Holding_Period_Days'] = hp_value
                
                input_data_df = pd.DataFrame(data_dict, index=dates).copy()
                
                # Save input data CSV
                input_filename = f"{output_dir}/{asset_class}_{algo_name}_input_data.csv"
                input_data_df.to_csv(input_filename)
                print(f"   {input_filename} ({len(input_data_df)} rows, {len(input_data_df.columns)} columns)")
                
                # Create separate CSV for weights allocation over time
                if portfolio_results and 't_port_wght' in portfolio_results and portfolio_results['t_port_wght'] is not None:
                    weights_df = portfolio_results['t_port_wght'].copy()
                    
                    # Add metadata columns
                    weights_df['Algorithm'] = data['algorithm'].name
                    weights_df['Asset_Class'] = asset_class.upper()
                    
                    # Add performance metrics for context
                    if algo_perf:
                        weights_df['Algorithm_Sharpe_Ratio'] = algo_perf['Sharpe Ratio']
                        weights_df['Algorithm_Annual_Return'] = algo_perf['Mean Return']
                        weights_df['Algorithm_Volatility'] = algo_perf['Std Dev']
                    
                    # Note: Decision logic removed for cleaner output
                    
                    # Calculate total absolute weights (sum of absolute values)
                    numeric_cols = weights_df.select_dtypes(include=[np.number]).columns
                    if len(numeric_cols) > 0:
                        weights_df['Total_Abs_Weight'] = weights_df[numeric_cols].abs().sum(axis=1)
                        weights_df['Max_Weight'] = weights_df[numeric_cols].abs().max(axis=1)
                        weights_df['Weight_Concentration'] = weights_df['Max_Weight'] / weights_df['Total_Abs_Weight']
                    
                    # Add weight change indicators
                    weight_cols = [col for col in weights_df.columns if not col.startswith(('Algorithm', 'Asset_Class', 'Decision', 'Total', 'Max', 'Weight_Concentration'))]
                    if weight_cols:
                        # Calculate weight changes (day-over-day)
                        for col in weight_cols[:10]:  # Limit to first 10 to avoid too many columns
                            if col in weights_df.columns:
                                weights_df[f'{col}_Change'] = weights_df[col].diff()
                                weights_df[f'{col}_Abs_Change'] = weights_df[col].diff().abs()
                    
                    # Save weights CSV
                    weights_filename = f"{output_dir}/{asset_class}_{algo_name}_weights_allocation.csv"
                    weights_df.to_csv(weights_filename)
                    print(f"   {weights_filename} ({len(weights_df)} rows, {len(weights_df.columns)} columns)")
                else:
                    print(f"    No weights data available for {asset_class}_{algo_name}")

            except Exception as e:
                print(f"   Error creating report for {asset_class}-{algo_name}: {e}")
    
    print(f"\n All CSV reports saved to '{output_dir}' directory")



def create_summary_performance_csv(all_results):
    """
    Creates a summary CSV showing comparative performance across all algorithms and asset classes
    """
    print("\nCreating performance summary CSV...")
    
    import os
    output_dir = "csv_reports"
    
    # Create summary dataframe
    summary_data = []
    
    for result in all_results:
        # Calculate additional metrics
        returns = result['Returns']
        
        # Calculate max drawdown
        cumulative = (1 + returns).cumprod()
        rolling_max = cumulative.expanding().max()
        drawdown = ((cumulative - rolling_max) / rolling_max).min()
        
        # Calculate win rate
        win_rate = (returns > 0).mean()
        
        # Calculate Calmar ratio (Annual return / Max Drawdown)
        calmar_ratio = abs(result['Mean Return'] / drawdown) if drawdown != 0 else 0
        
        # Calculate Sortino ratio (downside deviation)
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
        sortino_ratio = result['Mean Return'] / downside_std if downside_std != 0 else 0
        
        summary_data.append({
            'Asset_Class': result['Asset Class'],
            'Algorithm': result['Algorithm'],
            'Annualized_Return': result['Mean Return'],
            'Annualized_Volatility': result['Std Dev'],
            'Sharpe_Ratio': result['Sharpe Ratio'],
            'Max_Drawdown': drawdown,
            'Calmar_Ratio': calmar_ratio,
            'Sortino_Ratio': sortino_ratio,
            'Win_Rate': win_rate,
            'Total_Observations': len(returns),
            'Algorithm_Superiority_Score': result['Sharpe Ratio'] * 0.4 + calmar_ratio * 0.3 + win_rate * 0.3,
            'Decision_Quality': 'Excellent' if result['Sharpe Ratio'] > 1.5 else 
                              'Good' if result['Sharpe Ratio'] > 1.0 else 
                              'Average' if result['Sharpe Ratio'] > 0.5 else 'Poor',
            'Risk_Assessment': 'Low' if abs(drawdown) < 0.05 else 
                              'Medium' if abs(drawdown) < 0.15 else 'High',
            'Recommendation': generate_investment_recommendation(result, drawdown, win_rate)
        })
    
    summary_df = pd.DataFrame(summary_data)
    
    # Sort by Algorithm Superiority Score
    summary_df = summary_df.sort_values('Algorithm_Superiority_Score', ascending=False)
    
    # Save summary CSV
    summary_filename = f"{output_dir}/algorithm_performance_summary.csv"
    summary_df.to_csv(summary_filename, index=False)
    
    print(f"   {summary_filename}")
    
    # Create algorithm ranking CSV
    ranking_data = []
    for asset_class in summary_df['Asset_Class'].unique():
        ac_data = summary_df[summary_df['Asset_Class'] == asset_class].copy()
        ac_data['Rank'] = range(1, len(ac_data) + 1)
        
        for idx, row in ac_data.iterrows():
            key_strength = identify_key_strength(row)
            ranking_data.append({
                'Asset_Class': row['Asset_Class'],
                'Rank': row['Rank'],
                'Algorithm': row['Algorithm'],
                'Superiority_Score': row['Algorithm_Superiority_Score'],
                'Key_Strength': key_strength,
                'Why_Superior': explain_algorithm_superiority(row, ac_data, key_strength)
            })
    
    ranking_df = pd.DataFrame(ranking_data)
    ranking_filename = f"{output_dir}/algorithm_ranking_analysis.csv"
    ranking_df.to_csv(ranking_filename, index=False)
    
    print(f"   {ranking_filename}")

def generate_investment_recommendation(result, max_drawdown, win_rate):
    """Generate investment recommendation based on performance metrics"""
    sharpe = result['Sharpe Ratio']
    
    if sharpe > 1.5 and abs(max_drawdown) < 0.10 and win_rate > 0.55:
        return "Strongly Recommended - Excellent risk-adjusted returns with controlled downside"
    elif sharpe > 1.0 and abs(max_drawdown) < 0.15:
        return "Recommended - Good performance with acceptable risk"
    elif sharpe > 0.5 and win_rate > 0.50:
        return "Consider with Caution - Moderate performance, monitor closely"
    else:
        return "Not Recommended - Poor risk-adjusted performance"

def identify_key_strength(row):
    """Identify the key strength of the algorithm"""
    if row['Sharpe_Ratio'] == row['Sharpe_Ratio']:  # Check if not NaN
        max_metric = max(row['Sharpe_Ratio'], row['Calmar_Ratio'], row['Win_Rate'])
        
        if max_metric == row['Sharpe_Ratio']:
            return "Risk-Adjusted Returns"
        elif max_metric == row['Calmar_Ratio']:
            return "Drawdown Management"
        else:
            return "Consistent Positive Returns"
    return "Balanced Performance"

def explain_algorithm_superiority(row, asset_class_data, key_strength):
    """Explain why this algorithm is superior for this asset class"""
    rank = row['Rank']
    
    if rank == 1:
        reasons = []
        if row['Sharpe_Ratio'] > 1.0:
            reasons.append("highest Sharpe ratio")
        if abs(row['Max_Drawdown']) < asset_class_data['Max_Drawdown'].mean():
            reasons.append("superior drawdown control")
        if row['Win_Rate'] > asset_class_data['Win_Rate'].mean():
            reasons.append("highest win rate")
        
        return f"Best performer: {', '.join(reasons) if reasons else 'overall balanced performance'}"
    elif rank <= len(asset_class_data) // 2:
        return f"Above average performance in {key_strength.lower()}"
    else:
        return "Below average performance, needs improvement"

def run_strategy(asset_class, algorithm):
    """
    Runs a full investment strategy for a given asset class and weighting algorithm.
    """
    print(f"  > Running for Asset Class: '{asset_class.upper()}' using Algorithm: '{algorithm.name}'...")

    # Load Data
    nat_vol_rtn_mdf = all_returns[asset_class]
    signal_mdf = all_signals[asset_class]
    tcost_s = all_tcosts[asset_class]
    hold_s = all_holds[asset_class]

    # Logic to handle the special case of the Foundation Model
    if isinstance(algorithm, FoundationModel_Placeholder):
        conviction_df = algorithm.get_conviction_signal(nat_vol_rtn_mdf, signal_mdf)
    else:
        # Standard two-step process for online learning algorithms
        expert_weights_df = algorithm.get_weights(nat_vol_rtn_mdf, signal_mdf)
        common_idx = expert_weights_df.index.intersection(signal_mdf.index)
        expert_weights_aligned = expert_weights_df.reindex(common_idx)
        signal_mdf_aligned = signal_mdf.reindex(common_idx)
        
        w_signal_components = []
        assets_in_run = expert_weights_aligned.columns.get_level_values(0).unique()
        for asset in assets_in_run:
            if asset in signal_mdf_aligned.columns.get_level_values(0):
                asset_signals = signal_mdf_aligned[asset]
                asset_expert_weights = expert_weights_aligned[asset]
                weighted_asset_signals = asset_signals.mul(asset_expert_weights)
                w_signal_components.append(weighted_asset_signals.sum(axis=1).rename(asset))
        conviction_df = pd.concat(w_signal_components, axis=1)

    # Smooth the final conviction signal
    s_conviction_df = smooth_holding_period(conviction_df, hold_s)

    # Build Portfolio
    portfolio_param_dd = {
        'var_tgt_daily_pct': 0.01, 'risk_parity': True,
        'window': 250, 'min_window': 125, 'return_lag': 1
    }

    port_dd = portfolio_engine.calculate(
        weights_df=s_conviction_df,
        natural_ret_df=nat_vol_rtn_mdf,
        t_cost_s=tcost_s,
        **portfolio_param_dd
    )
    
    return port_dd

if __name__ == '__main__':
    try:
        # --- Configuration: Define all experiments to run ---
        ASSET_CLASSES = ['fx', 'rates', 'equity']
        
        # --- Hyperparameter Tuning Dictionary ---
        TUNED_PARAMS = {
            'fx':     {'alpha': 0.2, 'eta': 2.0},
            'rates':  {'alpha': 0.5, 'eta': 1.0},
            'equity': {'alpha': 0.6, 'eta': 0.8}
        }

        # --- Algorithm Factory as provided by user ---
        ALGORITHM_FACTORY = {
            "AA": lambda ac: AA_Algorithm(),
            "SEAA": lambda ac: SEAA_Algorithm(**TUNED_PARAMS.get(ac, {})),
            "FTL": lambda ac: FollowTheLeader(),
            "Hedge": lambda ac: HedgeAlgorithm(eta=2.0),
            "Foundation": lambda ac: FoundationModel_Placeholder()
        }

        # --- Data Loading ---
        print("Loading all data...")
        all_returns = data_loader.get_returns()
        all_signals = data_loader.get_risk_adj_signals()
        all_tcosts = data_loader.get_t_cost()
        all_holds = data_loader.get_holding_period()
        print("Data loaded successfully.\n")

        # --- Batch Execution ---
        all_results = []
        detailed_results = {}  # Store detailed data for CSV export
        
        print("Starting batch execution of all algorithms across all asset classes...")
        for ac in ASSET_CLASSES:
            detailed_results[ac] = {}
            
            for algo_name, algo_constructor in ALGORITHM_FACTORY.items():
                algo = algo_constructor(ac)
                portfolio_results = run_strategy(asset_class=ac, algorithm=algo)
                
                # Store detailed results for CSV export
                detailed_results[ac][algo_name] = {
                    'input_returns': all_returns[ac].copy(),
                    'input_signals': all_signals[ac].copy(),
                    'tcost': all_tcosts[ac].copy(),
                    'holding_periods': all_holds[ac].copy(),
                    'portfolio_results': portfolio_results,
                    'algorithm': algo
                }
                
                t_port_ret_df = portfolio_results.get('t_port_ret')
                if t_port_ret_df is not None and not t_port_ret_df.empty:
                    port_ret_s = t_port_ret_df.sum(axis=1)
                    
                    trading_days = 252
                    mean_ret = port_ret_s.mean() * trading_days
                    std_dev = port_ret_s.std() * np.sqrt(trading_days)
                    sharpe = mean_ret / std_dev if std_dev != 0 else 0

                    all_results.append({
                        'Asset Class': ac.upper(),
                        'Algorithm': algo.name,
                        'Mean Return': mean_ret,
                        'Std Dev': std_dev,
                        'Sharpe Ratio': sharpe,
                        'Returns': port_ret_s
                    })
        print("\nBatch execution complete.\n")

        # --- Prepare Dashboard Data ---
        dashboard_data = prepare_dashboard_data(detailed_results, all_results)
        
        # --- Optional: Generate Detailed CSV Reports (can be disabled) ---
        # Uncomment the lines below if you want CSV reports in addition to the dashboard
        # create_detailed_csv_reports(detailed_results, all_results)
        # create_summary_performance_csv(all_results)

        # --- Reporting ---
        if not all_results:
            print("No results were generated. Exiting.")
            sys.exit()

        results_df = pd.DataFrame(all_results)
        
        sharpe_pivot = results_df.pivot_table(index='Algorithm', columns='Asset Class', values='Sharpe Ratio')
        mean_ret_pivot = results_df.pivot_table(index='Algorithm', columns='Asset Class', values='Mean Return')
        std_dev_pivot = results_df.pivot_table(index='Algorithm', columns='Asset Class', values='Std Dev')


        print("--- PERFORMANCE SUMMARY ---")
        print("\n** Annualized Sharpe Ratio **")
        print(sharpe_pivot.to_string(float_format="%.2f"))
        print("\n** Annualized Mean Return **")
        print(mean_ret_pivot.to_string(float_format="%.4f"))
        print("\n** Annualized Volatility (Std Dev) **")
        print(std_dev_pivot.to_string(float_format="%.4f"))


        # ------------------- MODIFIED PLOTTING SECTION -------------------
        print("\nGenerating comparison plots...")
        plt.style.use('seaborn-v0_8-darkgrid')
        
        asset_classes_in_results = results_df['Asset Class'].unique()

        # 1. Create a figure and a set of subplots (axes) BEFORE the loop.
        fig, axes = plt.subplots(
            nrows=1, 
            ncols=len(asset_classes_in_results), 
            figsize=(22, 7), 
            constrained_layout=True,
            sharey=True  # Share the Y-axis range across subplots
        )
        fig.suptitle("Cumulative Wealth Comparison Across Asset Classes", fontsize=18, weight='bold')

        # Handle the case where there is only one asset class (axes is not an array)
        if len(asset_classes_in_results) == 1:
            axes = [axes]

        # 2. Loop through each asset class and its corresponding subplot axis.
        for i, ac_upper in enumerate(asset_classes_in_results):
            ax = axes[i] # Select the subplot for the current asset class
            
            ac_results = [res for res in all_results if res['Asset Class'] == ac_upper]
            
            if not ac_results:
                continue

            # 3. Plot all algorithm results on the selected subplot.
            for result in ac_results:
                wealth_index = (1 + result['Returns']).cumprod()
                label = f"{result['Algorithm']} (SR: {result['Sharpe Ratio']:.2f})"
                ax.plot(wealth_index.index, wealth_index, label=label)

            # 4. Customize the specific subplot.
            ax.legend(title='Algorithm (Sharpe Ratio)', loc='upper left', fontsize='small')
            ax.set_title(f"Asset Class: {ac_upper}", fontsize=14)
            ax.set_xlabel("Date")
            ax.set_yscale('log')
            ax.grid(True, which="both", ls="--")
            
            # --- CUSTOMIZATIONS AS REQUESTED ---
            # Apply smaller font size to all ticks on this subplot
            ax.tick_params(axis='both', which='major', labelsize=9)

            # Only show the y-axis label on the first plot (i=0)
            if i == 0:
                ax.set_ylabel("Cumulative Wealth (Log Scale)")
            else:
                # For other plots, hide the y-axis label and its tick labels
                ax.set_ylabel("")
                ax.tick_params(axis='y', labelleft=False)
        
        # 5. Handle any remaining (unused) subplots.
        for j in range(len(asset_classes_in_results), len(axes)):
            axes[j].set_visible(False)
            
        # 6. Show the single, combined figure.
        plt.show()
        
        # --- Launch Dashboard ---
        print("\n" + "="*60)
        print(" LAUNCHING INTERACTIVE DASHBOARD ")
        print("="*60)
        print("\nYour performance dashboard is ready!")
        print("Opening dashboard at: http://localhost:5000")
        print("\nPress Ctrl+C to stop the dashboard server.")
        print("="*60 + "\n")
        
        # Import and launch dashboard
        try:
            from dashboard import app, set_dashboard_data
            set_dashboard_data(dashboard_data)
            app.run(debug=False, port=5000, use_reloader=False)
        except ImportError:
            print("  Dashboard module not found. Skipping dashboard launch.")
            print("   Install Flask to use the dashboard: pip install flask plotly")

    except FileNotFoundError as e:
        print(f"\nFATAL ERROR: A required data file was not found: {e.filename}")
        print("Please ensure your data_loader is configured correctly.")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()
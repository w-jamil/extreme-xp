#!/usr/bin/env python3
"""
COMPREHENSIVE DELAYED & KERNELIZED REGRESSION EXPERIMENTS
=========================================================
"""

import collections
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION
# ============================================================================
N_SAMPLES = 5000
N_FEATURES = 5
NOISE_LEVEL = 0.1
DELAYS_TO_TEST = [0, 5, 10, 20, 50]
PACK_SIZES_TO_TEST = [1, 5, 10, 20, 50]
KERNELS_TO_TEST = ['linear', 'rbf', 'polynomial']
RBF_GAMMAS = [0.1, 1.0, 10.0]

# ============================================================================
# DATA GENERATION
# ============================================================================
def generate_data(n_samples, n_features, noise, seed=42):
    """Generates synthetic dataset."""
    print(f"  Generating {n_samples} samples, {n_features} features, noise={noise}")
    np.random.seed(seed)
    w_true = np.random.randn(n_features)
    X = np.random.rand(n_samples, n_features) * 2 - 1
    y_true = X @ w_true + np.random.randn(n_samples) * noise
    return X, y_true

# ============================================================================
# KERNEL FUNCTIONS
# ============================================================================
class KernelMatrix:
    """Manages kernel matrix computations."""
    
    def __init__(self, kernel_type='linear', gamma=1.0, degree=2, coef0=1.0):
        self.kernel_type = kernel_type
        self.gamma = gamma
        self.degree = degree
        self.coef0 = coef0
        self.X_history = []
    
    def kernel_fn(self, x1, x2):
        """Compute kernel between two vectors."""
        if self.kernel_type == 'linear':
            return np.dot(x1, x2)
        elif self.kernel_type == 'rbf':
            diff = x1 - x2
            return np.exp(-self.gamma * np.dot(diff, diff))
        elif self.kernel_type == 'polynomial':
            return (np.dot(x1, x2) + self.coef0) ** self.degree
        else:
            return np.dot(x1, x2)
    
    def compute_K_matrix(self, X1, X2=None):
        """Compute kernel matrix K(X1, X2)."""
        if X2 is None:
            X2 = X1
        n1, n2 = len(X1), len(X2)
        K = np.zeros((n1, n2))
        for i in range(n1):
            for j in range(n2):
                K[i, j] = self.kernel_fn(X1[i], X2[j])
        return K

# ============================================================================
# ALGORITHMS: DELAYED KERNELIZED AAIRR
# ============================================================================
class DelayedKAAIRR:
    """Kernelized AAIRR with Delayed Feedback."""
    
    def __init__(self, n_features, total_samples, kernel_type='linear', gamma=1.0):
        self.n_features = n_features
        self.total_samples = total_samples
        self.a = 1.0 / total_samples if total_samples > 0 else 1.0
        self.kernel = KernelMatrix(kernel_type=kernel_type, gamma=gamma)
        self.alpha = []  # Dual coefficients
        self.X_seen = []  # Stored examples
        self.y_seen = []  # Stored targets
        self.name = f"Delayed-KAAIRR({kernel_type})"
    
    def predict(self, x_t):
        """Predict using kernel expansion."""
        if len(self.X_seen) == 0:
            return 0.0
        
        # Compute kernel vector
        k_vec = np.array([self.kernel.kernel_fn(x_s, x_t) for x_s in self.X_seen])
        
        # Compute kernel matrix
        K = self.kernel.compute_K_matrix(np.array(self.X_seen))
        
        try:
            K_inv = np.linalg.inv(K + self.a * np.eye(len(self.X_seen)))
            alpha = K_inv @ np.array(self.y_seen)
            pred = np.dot(k_vec, alpha)
        except np.linalg.LinAlgError:
            pred = np.mean(self.y_seen) if self.y_seen else 0.0
        
        return pred
    
    def update(self, x_t, y_t):
        """Update with new example."""
        self.X_seen.append(x_t)
        self.y_seen.append(y_t)

class QuantumKAAIRR:
    """Quantum-inspired Kernelized AAIRR (amplitude amplification)."""
    
    def __init__(self, n_features, total_samples, kernel_type='linear', gamma=1.0):
        self.n_features = n_features
        self.total_samples = total_samples
        self.a = 1.0 / total_samples if total_samples > 0 else 1.0
        self.kernel = KernelMatrix(kernel_type=kernel_type, gamma=gamma)
        self.alpha = []
        self.X_seen = []
        self.y_seen = []
        self.quantum_amp = np.sqrt(total_samples)  # Amplitude amplification factor
        self.name = f"Quantum-KAAIRR({kernel_type})"
    
    def predict(self, x_t):
        """Predict with quantum amplification."""
        if len(self.X_seen) == 0:
            return 0.0
        
        k_vec = np.array([self.kernel.kernel_fn(x_s, x_t) for x_s in self.X_seen])
        K = self.kernel.compute_K_matrix(np.array(self.X_seen))
        
        try:
            K_inv = np.linalg.inv(K + self.a * np.eye(len(self.X_seen)))
            alpha = K_inv @ np.array(self.y_seen)
            pred = self.quantum_amp * np.dot(k_vec, alpha)
        except np.linalg.LinAlgError:
            pred = np.mean(self.y_seen) if self.y_seen else 0.0
        
        return pred
    
    def update(self, x_t, y_t):
        """Update with quantum-amplified gradient."""
        self.X_seen.append(x_t)
        self.y_seen.append(y_t * self.quantum_amp)

# ============================================================================
# SIMULATION: DELAYED FEEDBACK
# ============================================================================
def run_delayed_simulation(algo_class, X_data, y_data, delay, **kwargs):
    """Run simulation with delayed feedback."""
    n_samples, n_features = X_data.shape
    algo = algo_class(n_features=n_features, total_samples=n_samples, **kwargs)
    
    predictions = np.zeros(n_samples)
    feedback_buffer = collections.deque()
    
    for t in range(n_samples):
        x_t, y_t = X_data[t], y_data[t]
        
        # Predict
        predictions[t] = algo.predict(x_t)
        
        # Buffer feedback
        feedback_buffer.append((x_t, y_t))
        
        # Apply delayed update
        if len(feedback_buffer) > delay:
            x_delayed, y_delayed = feedback_buffer.popleft()
            algo.update(x_delayed, y_delayed)
    
    # Metrics
    rmse = np.sqrt(mean_squared_error(y_data, predictions))
    mae = mean_absolute_error(y_data, predictions)
    r2 = r2_score(y_data, predictions)
    mape = np.mean(np.abs((y_data - predictions) / (np.abs(y_data) + 1e-8))) * 100
    
    cumulative_loss = np.cumsum((predictions - y_data) ** 2)
    cumulative_loss = np.maximum(cumulative_loss, np.finfo(float).eps)
    
    return {
        'predictions': predictions,
        'cumulative_loss': cumulative_loss,
        'performance': {'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}
    }

def run_batch_simulation(algo_class, X_data, y_data, batch_size, **kwargs):
    """Run simulation with batch/pack updates."""
    n_samples, n_features = X_data.shape
    algo = algo_class(n_features=n_features, total_samples=n_samples, **kwargs)
    
    predictions = np.zeros(n_samples)
    
    for t in range(0, n_samples, batch_size):
        X_batch = X_data[t:t+batch_size]
        y_batch = y_data[t:t+batch_size]
        
        # Predict batch
        for i, x in enumerate(X_batch):
            predictions[t+i] = algo.predict(x)
        
        # Update with batch
        for i, (x, y) in enumerate(zip(X_batch, y_batch)):
            algo.update(x, y)
    
    rmse = np.sqrt(mean_squared_error(y_data, predictions))
    mae = mean_absolute_error(y_data, predictions)
    r2 = r2_score(y_data, predictions)
    mape = np.mean(np.abs((y_data - predictions) / (np.abs(y_data) + 1e-8))) * 100
    
    cumulative_loss = np.cumsum((predictions - y_data) ** 2)
    cumulative_loss = np.maximum(cumulative_loss, np.finfo(float).eps)
    
    return {
        'predictions': predictions,
        'cumulative_loss': cumulative_loss,
        'performance': {'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}
    }

# ============================================================================
# MAIN EXECUTION
# ============================================================================
def main():
    print("=" * 80)
    print("COMPREHENSIVE DELAYED & KERNELIZED REGRESSION EXPERIMENTS")
    print("=" * 80)
    
    # ========== PART 1: SIMULATED DATA WITH DELAYED FEEDBACK ==========
    print("\n[PART 1] SIMULATED DATA - DELAYED FEEDBACK SCENARIOS")
    print("-" * 80)
    
    X_sim, y_sim = generate_data(N_SAMPLES, N_FEATURES, NOISE_LEVEL)
    
    # --- Delayed Feedback Experiments ---
    print("\n1.1 Testing Delayed Feedback with Different Delays...")
    delay_results = {}
    for delay in DELAYS_TO_TEST:
        print(f"  Delay = {delay}:")
        result = run_delayed_simulation(DelayedKAAIRR, X_sim, y_sim, delay=delay, 
                                       kernel_type='rbf', gamma=1.0)
        delay_results[delay] = result
        print(f"    RMSE={result['performance']['RMSE']:.6f}, R²={result['performance']['R2']:.6f}")
    
    # --- Batch Size Experiments ---
    print("\n1.2 Testing Batch (Pack) Sizes with Different Sizes...")
    batch_results = {}
    for batch_size in PACK_SIZES_TO_TEST:
        print(f"  Batch Size = {batch_size}:")
        result = run_batch_simulation(DelayedKAAIRR, X_sim, y_sim, batch_size=batch_size,
                                     kernel_type='rbf', gamma=1.0)
        batch_results[batch_size] = result
        print(f"    RMSE={result['performance']['RMSE']:.6f}, R²={result['performance']['R2']:.6f}")
    
    # --- Kernel Type Experiments ---
    print("\n1.3 Testing Different Kernels (No Delay)...")
    kernel_results = {}
    for kernel_type in KERNELS_TO_TEST:
        print(f"  Kernel = {kernel_type}:")
        gamma = 1.0 if kernel_type == 'rbf' else 0.1
        result = run_delayed_simulation(DelayedKAAIRR, X_sim, y_sim, delay=0,
                                       kernel_type=kernel_type, gamma=gamma)
        kernel_results[kernel_type] = result
        print(f"    RMSE={result['performance']['RMSE']:.6f}, R²={result['performance']['R2']:.6f}")
    
    # --- Quantum Variants ---
    print("\n1.4 Testing Quantum-Inspired Variants...")
    quantum_results = {}
    for delay in [0, 5, 10]:
        print(f"  Quantum with Delay = {delay}:")
        result = run_delayed_simulation(QuantumKAAIRR, X_sim, y_sim, delay=delay,
                                       kernel_type='rbf', gamma=1.0)
        quantum_results[delay] = result
        print(f"    RMSE={result['performance']['RMSE']:.6f}, R²={result['performance']['R2']:.6f}")
    
    # ========== SAVE SIMULATED DATA RESULTS ==========
    print("\n[SAVING] Simulated Data Results to CSV...")
    
    # Delayed feedback summary
    delay_df = pd.DataFrame([
        {
            'Delay': d,
            'RMSE': result['performance']['RMSE'],
            'MAE': result['performance']['MAE'],
            'R2': result['performance']['R2'],
            'MAPE': result['performance']['MAPE'],
            'Final_Loss': result['cumulative_loss'][-1]
        }
        for d, result in delay_results.items()
    ])
    delay_df.to_csv('/home/wjamil/Documents/book/delayed/results_delay.csv', index=False)
    print("  ✓ Saved: results_delay.csv")
    
    # Batch size summary
    batch_df = pd.DataFrame([
        {
            'Batch_Size': b,
            'RMSE': result['performance']['RMSE'],
            'MAE': result['performance']['MAE'],
            'R2': result['performance']['R2'],
            'MAPE': result['performance']['MAPE'],
            'Final_Loss': result['cumulative_loss'][-1]
        }
        for b, result in batch_results.items()
    ])
    batch_df.to_csv('results_batch.csv', index=False)
    print("  Saved: results_batch.csv")
    
    # Kernel comparison
    kernel_df = pd.DataFrame([
        {
            'Kernel': k,
            'RMSE': result['performance']['RMSE'],
            'MAE': result['performance']['MAE'],
            'R2': result['performance']['R2'],
            'MAPE': result['performance']['MAPE'],
            'Final_Loss': result['cumulative_loss'][-1]
        }
        for k, result in kernel_results.items()
    ])
    kernel_df.to_csv('results_kernels.csv', index=False)
    print("  Saved: results_kernels.csv")
    
    # Quantum comparison
    quantum_df = pd.DataFrame([
        {
            'Delay': d,
            'Algorithm': 'Quantum-KAAIRR',
            'RMSE': result['performance']['RMSE'],
            'MAE': result['performance']['MAE'],
            'R2': result['performance']['R2'],
            'MAPE': result['performance']['MAPE'],
            'Final_Loss': result['cumulative_loss'][-1]
        }
        for d, result in quantum_results.items()
    ])
    quantum_df.to_csv('results_quantum.csv', index=False)
    print("   Saved: results_quantum.csv")
    
    # ========== PLOTS: SIMULATED DATA ==========
    print("\n[PLOTTING] Simulated Data Results...")
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.suptitle('Simulated Data: Delayed Feedback & Kernelized Regression', fontsize=16, fontweight='bold')
    
    # Plot 1: Delayed Feedback
    for delay, result in delay_results.items():
        axes[0, 0].plot(result['cumulative_loss'], label=f'Delay={delay}', alpha=0.7)
    axes[0, 0].set_xlabel('Time Steps')
    axes[0, 0].set_ylabel('Cumulative Loss (Linear)')
    axes[0, 0].set_title('Effect of Delayed Feedback')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # Plot 2: Delayed Feedback (Log Scale)
    for delay, result in delay_results.items():
        axes[0, 1].semilogy(result['cumulative_loss'], label=f'Delay={delay}', alpha=0.7)
    axes[0, 1].set_xlabel('Time Steps')
    axes[0, 1].set_ylabel('Cumulative Loss (Log Scale)')
    axes[0, 1].set_title('Effect of Delayed Feedback (Log Scale)')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3, which='both')
    
    # Plot 3: Batch Sizes
    for batch_size, result in batch_results.items():
        axes[0, 2].plot(result['cumulative_loss'], label=f'Batch={batch_size}', alpha=0.7)
    axes[0, 2].set_xlabel('Time Steps')
    axes[0, 2].set_ylabel('Cumulative Loss')
    axes[0, 2].set_title('Effect of Batch Size')
    axes[0, 2].legend()
    axes[0, 2].grid(True, alpha=0.3)
    
    # Plot 4: Kernel Types Comparison (Log)
    for kernel, result in kernel_results.items():
        axes[1, 0].semilogy(result['cumulative_loss'], label=f'{kernel}', alpha=0.7)
    axes[1, 0].set_xlabel('Time Steps')
    axes[1, 0].set_ylabel('Cumulative Loss (Log Scale)')
    axes[1, 0].set_title('Different Kernels Comparison')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3, which='both')
    
    # Plot 5: RMSE Comparison
    delays = sorted(delay_results.keys())
    delay_rmse = [delay_results[d]['performance']['RMSE'] for d in delays]
    quantum_delays = sorted(quantum_results.keys())
    quantum_rmse = [quantum_results[d]['performance']['RMSE'] for d in quantum_delays]
    
    x = np.arange(len(delays))
    width = 0.35
    axes[1, 1].bar(x - width/2, delay_rmse, width, label='Standard', alpha=0.8)
    axes[1, 1].bar(x + width/2, [quantum_results[d]['performance']['RMSE'] for d in delays], 
                   width, label='Quantum', alpha=0.8)
    axes[1, 1].set_xlabel('Delay (steps)')
    axes[1, 1].set_ylabel('RMSE')
    axes[1, 1].set_title('Standard vs Quantum KAAIRR')
    axes[1, 1].set_xticks(x)
    axes[1, 1].set_xticklabels(delays)
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3, axis='y')
    
    # Plot 6: R² Comparison
    delay_r2 = [delay_results[d]['performance']['R2'] for d in delays]
    quantum_r2 = [quantum_results[d]['performance']['R2'] for d in quantum_delays]
    
    axes[1, 2].bar(x - width/2, delay_r2, width, label='Standard', alpha=0.8)
    axes[1, 2].bar(x + width/2, quantum_r2, width, label='Quantum', alpha=0.8)
    axes[1, 2].set_xlabel('Delay (steps)')
    axes[1, 2].set_ylabel('R² Score')
    axes[1, 2].set_title('Standard vs Quantum R² Score')
    axes[1, 2].set_xticks(x)
    axes[1, 2].set_xticklabels(delays)
    axes[1, 2].legend()
    axes[1, 2].grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('plots_simulated.png', dpi=300, bbox_inches='tight')
    print("   Saved: plots_simulated.png")
    plt.close()
    
    # ========== SUMMARY TABLE ==========
    print("\n[SUMMARY] Simulated Data Results")
    print("\nDelayed Feedback Results:")
    print(delay_df.to_string(index=False))
    print("\nBatch Size Results:")
    print(batch_df.to_string(index=False))
    print("\nKernel Comparison:")
    print(kernel_df.to_string(index=False))
    print("\nQuantum Variants:")
    print(quantum_df.to_string(index=False))
    
    print("\n" + "=" * 80)
    print("EXPERIMENTS COMPLETED SUCCESSFULLY!")
    print("=" * 80)

if __name__ == '__main__':
    main()
